itemNums = int(input("Number of Items: "))
shoppingList = dict()

for i in range(itemNums):
    while(True):
        item_n_p = list(input("Input Item and Price: ").split())
        itemName = item_n_p[0]
        itemPrice = int(item_n_p[1])
        break
print(itemName,itemPrice)